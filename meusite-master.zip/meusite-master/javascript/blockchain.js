var enderecoContrato = "0x30cf0ed2cdc215db3b368ed2a8d1afe8e04c6633";
var provedor = new ethers.providers.Web3Provider(web3.currentProvider);
ethereum.enable();
var signatario = provedor.getSigner();
var contrato = new ethers.Contract(enderecoContrato, abiContrato, signatario);

function registrarPagamentocontaEnergia() {
    var textoCampo = document.frmStatus.txtPagamentocontaEnergia.value;
    var caixaStatusPagamentocontaEnergiaTx = document.getElementById("caixaStatusPagamentocontaEnergiaTx");
    if (textoCampo.length === 8) {
        caixaStatusPagamentocontaEnergiaTx.innerHTML = "Enviando transação...";
        contrato.mudaStatusPagamento(textoCampo)
        .then( (transacao) => {
            console.log("registrarPagamentocontaEnergia - Transacao ", transacao);   
            caixaStatusPagamentocontaEnergiaTx.innerHTML = "Transação enviada. Aguardando processamento...";
            transacao.wait()
            .then( (resultado) => {
                buscaStatusContrato();
                caixaStatusPagamentocontaEnergiaTx.innerHTML = "Transação realizada.";
            })       
            .catch( (err) => {
                console.error("registrarPagamentocontaEnergia - Aguardando tx ser minerada");
                console.error(err);
                caixaStatusPagamentocontaEnergiaTx.innerHTML = "Algo saiu errado: " + err.message;
            });
        })
        .catch( (err) => {
            console.error("registrarPagamentocontaEnergia");
            console.error(err);
            caixaStatusPagamentocontaEnergiaTx.innerHTML = "Algo saiu errado: " + err.message;
        });
    }
}

function registrarPagamentocontaEnergia() {
    var textoCampo = document.frmStatus.txtPagamentocontaEnergia.value;
    var caixaConsumoMensaltx = document.getElementById("caixaStatusPagamentocontaEnergiaTx");
    if (textoCampo.length === 8) {
        caixaStatusPagamentocontaEnergiaTx.innerHTML = "Enviando transação...";
        contrato.mudaStatusPagamento(textoCampo)
        .then( (transacao) => {
            console.log("registrarPagamentocontaEnergia - Transacao ", transacao);   
            caixaStatusPagamentocontaEnergiaTx.innerHTML = "Transação enviada. Aguardando processamento...";
            transacao.wait()
            .then( (resultado) => {
                buscaStatusContrato();
                caixaStatusPagamentocontaEnergiaTx.innerHTML = "Transação realizada.";
            })       
            .catch( (err) => {
                console.error("registrarPagamentocontaEnergia - Aguardando tx ser minerada");
                console.error(err);
                caixaStatusPagamentocontaEnergiaTx.innerHTML = "Algo saiu errado: " + err.message;
            });
        })
        .catch( (err) => {
            console.error("registrarPagamentocontaEnergia");
            console.error(err);
            caixaStatusPagamentocontaEnergiaTx.innerHTML = "Algo saiu errado: " + err.message;
        });
    }
}
    
function buscaContaEnergia() {
    var campoContaEnergia = document.getElementById("campoContaEnergia");     
    contrato.contaEnergia()
    .then( (contaEnergia) => {
        campoContaEnergia.innerHTML = contaEnergia;
    })
    .catch( (err) => {
        console.error(err);
        campoContaEnergia.innerHTML = err;
    });

}